from django.urls import path
from . import views

urlpatterns = [
  path('', views.index, name='dashboard-index'),
  path('staff/', views.staff, name='dashboard-staff'),
  path('product/', views.product, name='dashboard-product'),
  path('product/delete/<int:pk>', views.product_delete, name='dashboard-product-delete'),
  path('product/update/<int:pk>', views.product_update, name='dashboard-product-update'),
  path('order/', views.order, name='dashboard-order'),
  # path('opening-balance/', views.opening_balance, name='dashboard-opening-balance'),
  # path('add-purchase/', views.add_purchase, name='dashboard-add-purchase'),
  # path('issue-requisition/', views.issue_requisition, name='dashboard-issue-requisition'),
  # path('store-items/', views.store_items, name='dashboard-store-items'),
  # path('reports/', views.reports, name='dashboard-reports'),
  #path('user-list/', views.user_list, name='user_list'),
]

