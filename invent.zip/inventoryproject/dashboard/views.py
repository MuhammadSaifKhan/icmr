from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from .models import Product
from .forms import ProductForm
from user.forms import ProfileUpdateForm, UserUpdateForm
from user.models import Profile

@login_required
def index(request):
    return render(request, 'dashboard/index.html')

@login_required
def staff(request):
    return render(request, 'dashboard/staff.html')

@login_required
def product(request):
    items = Product.objects.all()

    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Product added successfully.")
            return redirect('dashboard-product')
    else:
        form = ProductForm()

    context = {'items': items, 'form': form}
    return render(request, 'dashboard/product.html', context)

def product_delete(request, pk):
    item = get_object_or_404(Product, id=pk)
    if request.method == 'POST':
        item.delete()
        messages.success(request, "Product deleted successfully.")
        return redirect('dashboard-product')
    return render(request, 'dashboard/product_delete.html')

def product_update(request, pk):
    item = get_object_or_404(Product, id=pk)
    if request.method == "POST":
        form = ProductForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('dashboard-product')
    else:
        form = ProductForm(instance=item)

    context = {'form': form}
    return render(request, 'dashboard/product_update.html', context)

@login_required
def order(request):
    return render(request, 'dashboard/order.html')

@login_required
def profile(request, employee_code):
    profile = get_object_or_404(Profile, employee_code=employee_code)
    context = {
        'profile': profile,
        'is_superuser': request.user.is_superuser,
        'current_user': request.user,
    }
    return render(request, 'user/profile.html', context)

@login_required
def profile_update(request, employee_code):
    profile = get_object_or_404(Profile, employee_code=employee_code)
    user = profile.staff

    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, instance=user)
        profile_form = ProfileUpdateForm(request.POST, instance=profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()

            # Handle password change
            new_password = user_form.cleaned_data.get('password')
            if new_password:
                user.set_password(new_password)
                user.save()
                login(request, user)

            messages.success(request, "Profile updated successfully.")
            return redirect('dashboard-index')  # Redirect to dashboard instead of user_list
    else:
        user_form = UserUpdateForm(instance=user)
        profile_form = ProfileUpdateForm(instance=profile)

    context = {
        'user_form': user_form,
        'profile_form': profile_form,
        'profile': profile,
        'is_superuser': request.user.is_superuser,
    }
    return render(request, 'user/profile_update.html', context)

