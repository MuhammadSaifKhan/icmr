from django.contrib import admin
from django.urls import path, include
from user import views as user_view  # Import your custom views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Admin panel route
    path('admin/', admin.site.urls),

    # Login route (default homepage points to login)
    path('', user_view.login_view, name='user-login'),

    # Dashboard routes (e.g., /dashboard/)
    path('dashboard/', include('dashboard.urls')),

    # User management routes
    path('register/', user_view.register, name='user-register'),
    path('profile/<str:emp_code>/', user_view.profile, name='user-profile'),  # Profile details page
    path('profile/update/', user_view.profile_update, name='user-profile-update'),  # Profile update page
    path('user_list/', user_view.user_list, name='user_list'),

    # Logout route
    path('logout/', user_view.logout_view, name='user-logout'),
]

# Serve media files during development (e.g., user-uploaded files like images)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
