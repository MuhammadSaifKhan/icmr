from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Profile

class CreateUserForm(UserCreationForm):
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile  # Ensure that the Profile model exists
        fields = ['employee_name', 'designation', 'division', 'phone', 'is_head', 'status']

class UserUpdateForm(forms.ModelForm):
    password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(attrs={'placeholder': 'Enter new password'}),
        help_text="Leave blank if you don't want to change the password.",
    )

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    
    def save(self, commit=True):
        user = super(UserUpdateForm, self).save(commit=False)
        password = self.cleaned_data.get('password')
        if password:  # Only set a new password if one is provided
            user.set_password(password)
        else:
            # Fetch the existing password from the database if none is provided
            existing_user = User.objects.get(pk=user.pk)
            user.password = existing_user.password
        if commit:
            user.save()
        return user

class ProfileUpdateForm(forms.ModelForm):
    is_head = forms.ChoiceField(
        choices=[(True, 'Yes'), (False, 'No')],
        widget=forms.RadioSelect,
    )

    class Meta:
        model = Profile
        fields = ['employee_name', 'designation', 'division', 'phone', 'is_head', 'status']
