from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):
    staff = models.OneToOneField(User, on_delete=models.CASCADE, null=True)
    employee_code = models.CharField(max_length=20, unique=True, null=True)
    employee_name = models.CharField(max_length=100, null=True)
    designation = models.CharField(max_length=100, null=True)
    division = models.CharField(max_length=200, null=True)
    phone = models.CharField(max_length=20, null=True)
    is_head = models.BooleanField(default=False)
    status = models.CharField(max_length=20, choices=[('Active', 'Active'), ('Inactive', 'Inactive')], default='Active')

    def __str__(self):
        return f'{self.staff.username} - Profile'
