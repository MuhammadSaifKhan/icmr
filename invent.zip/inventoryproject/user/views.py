from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout
from django.contrib.auth.models import User
import requests
from .forms import CreateUserForm, UserUpdateForm, ProfileUpdateForm

# Function to fetch employee profile from the API
def fetch_employee_profile(loginid, user_token):
    api_url = "https://irras.icmr.org.in/index.php/apiemployeeprofile"
    payload = {"loginid": loginid, "user_token": user_token}

    try:
        response = requests.post(api_url, json=payload)
        data = response.json()
        print("API Response:", data)  # Debugging full API response
        if response.status_code == 200 and data.get("status"):
            return data["data"]
        elif data.get("msg") == "loginid and token are invalid!":
            print("Error: Token is invalid. User needs to log in again.")
            return {"error": "invalid_token"}  # Indicate invalid token
    except Exception as e:
        print(f"Error fetching profile: {e}")
    return None

# Custom Login View
def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        api_url = "https://irras.icmr.org.in/index.php/apploginapi"
        payload = {"username": username, "password": password}

        try:
            response = requests.post(api_url, json=payload)
            if response.status_code == 200:
                data = response.json()
                if data.get("status"):
                    loginid = data["data"]["loginid"]
                    user_token = data["data"]["user_token"]
                    request.session["loginid"] = loginid
                    request.session["user_token"] = user_token

                    # Fetch employee profile
                    profile_data = fetch_employee_profile(loginid, user_token)
                    if profile_data and "empprofile" in profile_data:
                        empprofile = profile_data["empprofile"]
                        request.session["employee_name"] = empprofile.get("Name", "Unknown")
                        request.session["employee_code"] = empprofile.get("emp_code", "N/A")  # Set employee_code
                        request.session["designation"] = empprofile.get("Designation", "N/A")
                    else:
                        request.session["employee_name"] = "Unknown"
                        request.session["employee_code"] = "N/A"  # Default fallback
                        request.session["designation"] = "N/A"

                    # Create or retrieve the user in Django's auth system
                    user, created = User.objects.get_or_create(username=username)
                    if created:
                        user.set_unusable_password()
                        user.save()

                    # Log the user in
                    login(request, user)
                    messages.success(request, "Login successful!")
                    return redirect("dashboard-index")
                else:
                    messages.error(request, "Invalid username or password.")
            else:
                messages.error(request, "Failed to connect to the login service.")
        except Exception as e:
            messages.error(request, f"An error occurred: {str(e)}")

    return render(request, "user/login.html")

# Custom Logout View
def logout_view(request):
    logout(request)
    request.session.flush()
    messages.success(request, "You have been logged out successfully.")
    return redirect("user-login")


# User Registration View
def register(request):
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, "Account created successfully!")
            return redirect('user-login')
    else:
        form = CreateUserForm()

    return render(request, 'user/register.html', {'form': form})


# Profile View
@login_required
def profile(request, emp_code):
    loginid = request.session.get("loginid")
    user_token = request.session.get("user_token")

    print("Debug: Session Variables - loginid:", loginid, "user_token:", user_token)

    if not loginid or not user_token:
        messages.error(request, "Session expired. Please log in again.")
        return redirect("user-login")

    # Fetch profile data
    profile_data = fetch_employee_profile(loginid, user_token)
    if profile_data and "error" in profile_data and profile_data["error"] == "invalid_token":
        messages.error(request, "Your session has expired. Please log in again.")
        return redirect("user-login")

    if not profile_data or "empprofile" not in profile_data:
        messages.error(request, "Unable to fetch profile details. Please try again later.")
        return redirect("dashboard-index")

    return render(request, "user/profile.html", {"profile": profile_data["empprofile"]})

# Profile Update View
@login_required
def profile_update(request):
    loginid = request.session.get("loginid")
    user_token = request.session.get("user_token")

    if not loginid or not user_token:
        messages.error(request, "Session expired. Please log in again.")
        return redirect("user-login")

    profile_data = fetch_employee_profile(loginid, user_token)
    if not profile_data or "empprofile" not in profile_data:
        messages.error(request, "Unable to fetch profile details.")
        return redirect("dashboard-index")

    if request.method == "POST":
        user_form = UserUpdateForm(request.POST)
        profile_form = ProfileUpdateForm(request.POST)

        if user_form.is_valid() and profile_form.is_valid():
            messages.success(request, "Profile updated successfully!")
            return redirect("user-profile")
    else:
        empprofile = profile_data["empprofile"]
        user_form = UserUpdateForm(initial={"username": empprofile.get("loginid")})
        profile_form = ProfileUpdateForm(initial={
            "employee_name": empprofile.get("Name"),
            "designation": empprofile.get("Designation"),
            "division": empprofile.get("Field_Unit"),
            "phone": empprofile.get("Mobile"),
        })

    return render(request, "user/profile_update.html", {
        "user_form": user_form,
        "profile_form": profile_form,
    })


# User List View
@login_required
def user_list(request):
    if not request.user.is_staff:
        messages.error(request, "You do not have permission to access this page.")
        return redirect("dashboard-index")

    loginid = request.session.get("loginid")
    user_token = request.session.get("user_token")

    if not loginid or not user_token:
        messages.error(request, "Session expired. Please log in again.")
        return redirect("user-login")

    api_url = "https://irras.icmr.org.in/index.php/apiemployeelisting"
    payload = {"loginid": loginid, "user_token": user_token}
    try:
        response = requests.post(api_url, json=payload)
        if response.status_code == 200:
            data = response.json()
            if data.get("status"):
                user_list_data = data.get("data", {}).get("empListing", [])
                return render(request, "dashboard/user_list.html", {"users": user_list_data})
            else:
                messages.error(request, "Failed to fetch user list.")
        else:
            messages.error(request, "Error fetching data from the server.")
    except Exception as e:
        messages.error(request, f"An error occurred: {str(e)}")

    return render(request, "dashboard/user_list.html", {"users": []})
